package T929.C1;

public class BlackHuman implements Human{
    @Override
    public void getColor(){
        System.out.println("Black");
    }
    public void talk(){
        System.out.println("BlackTalk");
    }
}
