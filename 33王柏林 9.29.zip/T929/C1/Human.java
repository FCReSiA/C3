package T929.C1;

public interface Human {
    public void getColor();
    public void talk();
}
