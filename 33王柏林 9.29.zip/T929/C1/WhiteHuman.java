package T929.C1;

public class WhiteHuman implements Human{
    public void getColor() {
        System.out.println("White");
    }

    public void talk() {
        System.out.println("WhiteTalk");
    }

}
