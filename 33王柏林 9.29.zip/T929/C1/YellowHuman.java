package T929.C1;

public class YellowHuman implements Human{
    public void getColor(){
        System.out.println("Yellow");
    }
    public void talk(){
        System.out.println("YellowTalk");
    }
}