package T929.C2;

public class FemaleBlackHuman extends AbstractBlackHuman{
    @Override
    public void getSex() {
        System.out.println("BlackGirl");
    }
}
