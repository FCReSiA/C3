package T929.C2;

public class FemaleBrownHuman extends AbstractBrownHuman{
    @Override
    public void getSex() {
        System.out.println("BrownGirl");
    }
}
