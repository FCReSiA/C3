package T929.C2;

public class FemaleWhiteHuman extends AbstractWhiteHuman{

    @Override
    public void getSex() {
        System.out.println("WhiltGirl");
    }
}
