package T929.C2;

public class FemaleYellowHuman extends AbstractYellowHuman{
    @Override
    public void getSex() {
        System.out.println("YellowGirl");
    }
}
