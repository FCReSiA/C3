package T929.C2;

public interface Human {
    public void getColor();
    public void talk();
    public void getSex();
}
