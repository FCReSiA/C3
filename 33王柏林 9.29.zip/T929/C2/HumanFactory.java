package T929.C2;

public interface HumanFactory {
    public  Human createYellowHuman();

    public  Human createWhiteHuman();

    public  Human createBlackHuman();

    public  Human createBrownHuman();

}
