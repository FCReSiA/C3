package T929.C2;

public class IntersexBlackHuman extends AbstractBlackHuman{
    @Override
    public void getSex() {
        System.out.println("BlackBoth");
    }
}
