package T929.C2;

public class IntersexBrownHuman extends AbstractBrownHuman{
    @Override
    public void getSex() {
        System.out.println("BrownBoth");
    }
}
