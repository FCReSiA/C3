package T929.C2;

public class IntersexWhiteHuman extends AbstractWhiteHuman{
    @Override
    public void getSex() {
        System.out.println("WhiteBoth");
    }
}
