package T929.C2;

public class IntersexYellowHuman extends AbstractYellowHuman{
    @Override
    public void getSex() {
        System.out.println("YellowBoth");
    }
}
