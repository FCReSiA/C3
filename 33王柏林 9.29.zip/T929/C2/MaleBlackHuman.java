package T929.C2;

public class MaleBlackHuman extends AbstractBlackHuman{

        public void getSex()
        {
                System.out.println("BlackMan");
        }


}
