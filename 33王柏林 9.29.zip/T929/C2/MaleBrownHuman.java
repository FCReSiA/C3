package T929.C2;

public class MaleBrownHuman extends AbstractBrownHuman{

    public void getSex()
    {
        System.out.println("BrownMan");
    }


}
