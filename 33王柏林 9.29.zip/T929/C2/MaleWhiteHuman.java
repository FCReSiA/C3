package T929.C2;

public class MaleWhiteHuman extends AbstractWhiteHuman{

        public void getSex()
        {
                System.out.println("WhiteMan");
        }


}
