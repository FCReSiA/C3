package T929.C2;

public class MaleYellowHuman extends AbstractYellowHuman{

        public void getSex()
        {
                System.out.println("YellowMan");
        }


}
