package com.itheima.jdk;

public interface UserDao {
        public void addUser();
        public void deleteUser();
}
